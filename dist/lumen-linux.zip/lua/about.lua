-- about: RPC layer for the Lumen settings menu's "About" tab.
--
-- Exposes two backend methods (registered into the CDP dispatch registry by
-- register()), each returning a JSON string per the callServerMethod convention
-- the polyfill resolves:
--   GetAboutVersions() -> {success, components=[{key,name,installed,latest,state}]}
--   UpdateAll()        -> {success[, error]}  (opens a terminal running install.sh)
--
-- Versions are sourced from the RELEASES, not local files: the plugin's bundled
-- version string is unreliable, so the canonical "installed" marker is the
-- release tag the installer stamps into versions.json at install time, compared
-- against each repo's latest published release tag (GitHub releases API). When
-- the stamp is absent (installs predating it) "installed" reads as unknown and
-- the tab still shows the latest + offers Update All.
--
-- The pure helpers (tag parse/normalize/compare, terminal detection, command
-- building) take their effects (http, fs, which) as injectable args so they are
-- host-testable without a network or a desktop (tools/test_about.lua).
local json = require("json")

local about = {}

-- The three stack components, in display order. `key` matches the versions.json
-- field the installer writes; `repo` is the GitHub owner/name for the API;
-- `asset_pat` is a Lua pattern matching the release asset filename (so we can
-- read THAT asset's fingerprint, not just the tag).
about.COMPONENTS = {
  { key = "slsteam_moon", name = "slsteam-moon",    repo = "swwayps/slsteam-moon",
    asset_pat = "^slsteam%-moon%-linux%-.*%-lumen%.zip$",
    beta_path = "dist/slsteam-moon-linux.zip" },
  { key = "plugin",       name = "LuaTools plugin", repo = "swwayps/luatools-moon",
    asset_pat = "^luatools%-linux%.zip$",
    beta_path = "dist/luatools-linux.zip" },
  { key = "lumen",        name = "Lumen",           repo = "swwayps/lumen",
    asset_pat = "^lumen%-linux%.zip$",
    beta_path = "dist/lumen-linux.zip" },
}

-- The public one-liner the Update All button runs in a terminal. Raw-branch URL
-- (not a release asset) so installer fixes go live without a rebuild.
about.INSTALL_URL =
  "https://raw.githubusercontent.com/swwayps/luatools-moon/main/install.sh"

-- Where the installer stamps the installed release tags.
function about.versions_path()
  local home = os.getenv("HOME") or ""
  return home .. "/.local/share/Lumen/versions.json"
end

-- Unified update-channel preference. The file keeps the legacy per-component
-- shape so older installers remain compatible, but all three values are always
-- normalized to one channel. A mixed legacy file migrates toward Beta when any
-- component requested it, preserving the user's opt-in.
function about.channels_path()
  local home = os.getenv("HOME") or ""
  return home .. "/.local/share/Lumen/update-channels.json"
end

local CHANNEL_KEYS = { "slsteam_moon", "plugin", "lumen" }
local function valid_channel(value)
  return value == "beta" and "beta" or "stable"
end

function about.normalize_channels(raw)
  raw = type(raw) == "table" and raw or {}
  local channel = valid_channel(raw.channel)
  if channel ~= "beta" then
    for _, key in ipairs(CHANNEL_KEYS) do
      if raw[key] == "beta" then channel = "beta"; break end
    end
  end
  local out = {}
  for _, key in ipairs(CHANNEL_KEYS) do out[key] = channel end
  return out
end

function about.read_channels(path, read_file)
  read_file = read_file or function(p)
    local f = io.open(p, "rb"); if not f then return nil end
    local d = f:read("*a"); f:close(); return d
  end
  local raw = read_file(path)
  if type(raw) ~= "string" or raw == "" then
    return about.normalize_channels(nil)
  end
  local ok, decoded = pcall(json.decode, raw)
  if not ok then decoded = nil end
  return about.normalize_channels(decoded)
end

-- Atomic save: write a complete sibling file, then replace the destination.
-- Effects are injectable so the contract is host-testable without disk IO.
function about.save_channels(path, channels, deps)
  deps = deps or {}
  local write_file = deps.write_file or function(p, body)
    local f = io.open(p, "wb"); if not f then return false end
    local ok = f:write(body); f:close(); return ok and true or false
  end
  local rename = deps.rename or os.rename
  local remove = deps.remove or os.remove
  local tmp = path .. ".tmp"
  local body = json.encode(about.normalize_channels(channels))
  if not write_file(tmp, body) then return false, "could not write channel preferences" end
  local ok, err = rename(tmp, path)
  if not ok then
    pcall(remove, tmp)
    return false, err or "could not replace channel preferences"
  end
  return true
end

function about.set_channel(path, channel, deps)
  if channel ~= "stable" and channel ~= "beta" then
    return false, "unknown channel"
  end
  return about.save_channels(path, { channel = channel }, deps)
end

-- read_installed(path[, read_file]) -> table of key->tag (empty table on any
-- failure). `read_file` defaults to a plain io read so it's injectable in tests.
function about.read_installed(path, read_file)
  read_file = read_file or function(p)
    local f = io.open(p, "rb"); if not f then return nil end
    local d = f:read("*a"); f:close(); return d
  end
  local raw = read_file(path)
  if not raw or raw == "" then return {} end
  local ok, data = pcall(json.decode, raw)
  if not ok or type(data) ~= "table" then return {} end
  return data
end

-- installed_entry(installed, key) -> { tag, asset_at, size, id } for one
-- component, tolerating both the rich object shape the installer now writes
-- ({tag, asset_at, size, id}) and the legacy flat-string shape ("v2.6", tag only).
--
-- json.decode renders a JSON `null` as a truthy sentinel (NOT nil), so a stamp
-- like {asset_at:null,size:null,id:null} — written when the forge didn't return
-- those fields at install time — would otherwise read as a present-but-different
-- fingerprint and trigger a bogus "update". Each field is therefore accepted
-- only when it has its expected concrete type; anything else (sentinel, missing)
-- collapses to nil so the entry degrades cleanly to a tag-only legacy stamp.
function about.installed_entry(installed, key)
  local v = installed and installed[key]
  if type(v) == "table" then
    return {
      tag      = (type(v.tag) == "string" and v.tag ~= "" and v.tag) or nil,
      asset_at = (type(v.asset_at) == "string" and v.asset_at ~= "" and v.asset_at) or nil,
      size     = (type(v.size) == "number" and v.size) or nil,
      id       = ((type(v.id) == "number" or type(v.id) == "string") and v.id) or nil,
      channel  = valid_channel(v.channel),
    }
  elseif type(v) == "string" and v ~= "" then
    return { tag = v, channel = "stable" }  -- legacy: tag only, no asset fingerprint
  end
  return {}
end

-- Normalize a release tag for comparison: trim, drop a leading "v", lowercase.
-- "v2.5" and "2.5" compare equal; nil/"" -> nil.
function about.norm_tag(tag)
  if type(tag) ~= "string" then return nil end
  local t = tag:gsub("^%s+", ""):gsub("%s+$", "")
  if t == "" then return nil end
  t = t:gsub("^[vV]", "")
  return t:lower()
end

-- ISO timestamp ("2026-06-21T03:15:25+02:00") -> "dd/mm/yyyy". "" on nil/garbage.
-- A build date shown next to the tag so an asset-only update (same tag, newer
-- upload) reads clearly instead of looking like "v2.6 vs v2.6, why update?".
function about.fmt_date(iso)
  if type(iso) ~= "string" then return "" end
  local y, m, d = iso:match("^(%d%d%d%d)%-(%d%d)%-(%d%d)")
  if not y then return "" end
  return d .. "/" .. m .. "/" .. y
end

-- fmt_asset(id) -> "#<id>" or "". GitHub's asset id is the unique identifier of
-- a SPECIFIC uploaded file: re-uploading the asset (even under the same release
-- tag) yields a brand-new id. Showing it next to the version makes an
-- asset-only update legible ("#248139923 vs #251004412") instead of the
-- confusing "v2.6 vs v2.6, why update?". Non-id values (sentinel/missing) -> "".
function about.fmt_asset(id)
  if type(id) == "number" then
    return "#" .. string.format("%d", id)
  elseif type(id) == "string" and id ~= "" then
    -- Release asset ids are short numbers; beta ids are Git blob SHAs. Keep
    -- the latter legible without letting the version line grow unpredictably.
    return "#" .. (#id > 12 and id:sub(1, 12) or id)
  end
  return ""
end

-- compare_state(inst, latest) -> "current" | "update" | "unknown", where inst
-- and latest are { tag, asset_at, size, id } tables. An update is reported when
-- ANY signal changed, so both release workflows are covered:
--   * tag bump (e.g. v2.6 -> v2.7)                                   -> update
--   * SAME tag, asset re-uploaded (new asset id / upload time / size) -> update
-- The asset id is the canonical per-upload identifier (a re-upload always gets a
-- fresh one), so it's preferred when both sides carry it; the asset_at+size
-- fingerprint is the fallback for stamps written before ids were recorded, and a
-- bare tag comparison is the last resort for legacy tag-only stamps. No latest,
-- or no installed identity at all -> unknown.
function about.compare_state(inst, latest)
  inst = inst or {}
  latest = latest or {}
  local lt = about.norm_tag(latest.tag)
  if not lt then return "unknown" end
  local it = about.norm_tag(inst.tag)
  -- No installed identity (no tag, no asset fingerprint at all) -> can't tell.
  if not it and not inst.asset_at and inst.id == nil then return "unknown" end
  -- 1) Tag changed -> update (caught even if we can't compare assets).
  if it and it ~= lt then return "update" end
  -- 2) Same (or unknown) tag: the asset id is the most precise signal.
  if inst.id ~= nil and latest.id ~= nil then
    if tostring(inst.id) ~= tostring(latest.id) then return "update" end
    return "current"
  end
  -- 3) No id on one side: compare the upload-time + size fingerprint.
  if inst.asset_at and latest.asset_at then
    if inst.asset_at ~= latest.asset_at
        or tostring(inst.size or "") ~= tostring(latest.size or "") then
      return "update"
    end
    return "current"
  end
  -- 4) No asset fingerprint to compare (legacy stamp): tags match -> current.
  if it and it == lt then return "current" end
  return "unknown"
end

-- API URL for a repo's latest published (non-draft, non-prerelease) release.
function about.api_url(repo)
  return "https://api.github.com/repos/" .. repo .. "/releases/latest"
end

-- GitHub's contents endpoint returns only small metadata and proves both the
-- beta branch and its expected dist asset exist; it never downloads the ZIP.
function about.beta_api_url(component)
  return "https://api.github.com/repos/" .. component.repo .. "/contents/"
    .. component.beta_path .. "?ref=beta"
end

function about.parse_beta_info(body)
  if type(body) ~= "string" or body == "" then return nil end
  local ok, data = pcall(json.decode, body)
  if not ok or type(data) ~= "table" then return nil end
  if type(data.sha) ~= "string" or data.sha == ""
      or type(data.download_url) ~= "string" or data.download_url == "" then
    return nil
  end
  return {
    tag = "beta",
    channel = "beta",
    id = data.sha,
    size = type(data.size) == "number" and data.size or nil,
    download_url = data.download_url,
  }
end

function about.fetch_beta_info(component, http_mod)
  local r, _ = http_mod.get(about.beta_api_url(component), {
    timeout = 4,
    headers = { ["Accept"] = "application/vnd.github+json", ["User-Agent"] = "lumen" },
  })
  if not r or r.status ~= 200 then return nil end
  return about.parse_beta_info(r.body)
end

-- parse_latest_info(body, asset_pat) -> { tag, asset_at, size, id } or nil. Pure
-- (decode only). Finds the asset whose name matches `asset_pat` and returns its
-- upload fingerprint (id + created_at + size) alongside the release tag.
function about.parse_latest_info(body, asset_pat)
  if type(body) ~= "string" or body == "" then return nil end
  local ok, data = pcall(json.decode, body)
  if not ok or type(data) ~= "table" then return nil end
  local tag = data.tag_name
  if type(tag) ~= "string" or tag == "" then return nil end
  local info = { tag = tag }
  local assets = data.assets
  if type(assets) == "table" then
    for _, a in ipairs(assets) do
      if type(a) == "table" and type(a.name) == "string"
          and a.name:match(asset_pat) then
        info.asset_at = (type(a.created_at) == "string" and a.created_at) or nil
        info.size = (type(a.size) == "number" and a.size) or nil
        info.id = ((type(a.id) == "number" or type(a.id) == "string") and a.id) or nil
        break
      end
    end
  end
  return info
end

-- fetch_latest_info(component, http_mod) -> { tag, asset_at, size } or nil.
-- Short timeout so a slow/down forge doesn't stall the injector loop.
function about.fetch_latest_info(component, http_mod)
  local r, _ = http_mod.get(about.api_url(component.repo), {
    timeout = 6,
    headers = { ["Accept"] = "application/json", ["User-Agent"] = "lumen" },
  })
  if not r or r.status ~= 200 then return nil end
  return about.parse_latest_info(r.body, component.asset_pat)
end

-- get_versions(opts) -> table {success=true, components={...}}. opts (all
-- optional, injectable for tests):
--   http        : http module (defaults to require("http"))
--   read_file   : reader for the versions stamp
--   versions_path : override the stamp path
function about.get_versions(opts)
  opts = opts or {}
  local http_mod = opts.http or require("http")
  -- include_plugin defaults to true; a --noplugin install passes false so the
  -- LuaTools plugin row is dropped from the About tab's version list.
  local include_plugin = opts.include_plugin ~= false
  local installed = about.read_installed(
    opts.versions_path or about.versions_path(), opts.read_file)
  local channels = about.read_channels(
    opts.channels_path or about.channels_path(), opts.read_file)

  local out = {}
  for _, c in ipairs(about.COMPONENTS) do
    if include_plugin or c.key ~= "plugin" then
      local inst = about.installed_entry(installed, c.key)
      local stable_latest = about.fetch_latest_info(c, http_mod)
      local beta_latest = about.fetch_beta_info(c, http_mod)
      local beta_available = beta_latest ~= nil
      local channel = channels[c.key] == "beta" and beta_available and "beta" or "stable"
      local latest = channel == "beta" and beta_latest or stable_latest
      local stable_state = about.compare_state(inst, stable_latest)
      local beta_state = beta_available
        and about.compare_state(inst, beta_latest) or stable_state
      out[#out + 1] = {
        key = c.key,
        name = c.name,
        channel = channel,
        betaAvailable = beta_available,
        channelStates = {
          stable = stable_state,
          beta = beta_state,
        },
        installed = inst.tag or "",
        latest = (latest and latest.tag) or "",
        installedBuild = about.fmt_date(inst.asset_at),
        latestBuild = about.fmt_date(latest and latest.asset_at),
        installedAsset = about.fmt_asset(inst.id),
        latestAsset = about.fmt_asset(latest and latest.id),
        state = channel == "beta" and beta_state or stable_state,
      }
    end
  end
  return {
    success = true,
    channel = channels.slsteam_moon,
    components = out,
  }
end

-- Start every release lookup concurrently for the tiny menubar boot status.
-- The returned handles are advanced only by poll_update_probe(), so neither an
-- RPC handler nor any Steam thread waits on network I/O.
function about.new_update_probe(opts)
  opts = opts or {}
  local http_mod = opts.http or require("http")
  if type(http_mod.start) ~= "function" or type(http_mod.poll) ~= "function" then
    return nil, "asynchronous HTTP is unavailable"
  end
  local probe = {
    http = http_mod,
    installed = about.read_installed(
      opts.versions_path or about.versions_path(), opts.read_file),
    channels = about.read_channels(
      opts.channels_path or about.channels_path(), opts.read_file),
    tasks = {},
  }
  local include_plugin = opts.include_plugin ~= false
  local request_opts = {
    timeout = 6,
    max_bytes = 2 * 1024 * 1024,
    headers = { ["Accept"] = "application/vnd.github+json", ["User-Agent"] = "lumen" },
  }
  local function start(url)
    local ok, handle = pcall(http_mod.start, url, request_opts)
    return { handle = ok and handle or nil, done = not (ok and handle) }
  end
  for _, component in ipairs(about.COMPONENTS) do
    if include_plugin or component.key ~= "plugin" then
      probe.tasks[#probe.tasks + 1] = {
        component = component,
        stable = start(about.api_url(component.repo)),
        beta = probe.channels[component.key] == "beta"
          and start(about.beta_api_url(component)) or { done = true },
      }
    end
  end
  return probe
end

local function poll_update_slot(http_mod, slot)
  if slot.done then return end
  local ok, done, response = pcall(http_mod.poll, slot.handle)
  if not ok then slot.done = true; return end
  if done ~= true then return end
  slot.done = true
  slot.response = response
  slot.handle = nil
end

function about.poll_update_probe(probe)
  if type(probe) ~= "table" or type(probe.tasks) ~= "table"
      or type(probe.http) ~= "table" then
    return { success = false, pending = false, available = false }
  end
  if probe.result then return probe.result end
  local pending = false
  for _, task in ipairs(probe.tasks) do
    poll_update_slot(probe.http, task.stable)
    poll_update_slot(probe.http, task.beta)
    if not task.stable.done or not task.beta.done then pending = true end
  end
  if pending then return { success = true, pending = true, available = false } end

  local available = false
  for _, task in ipairs(probe.tasks) do
    local stable_response = task.stable.response
    local beta_response = task.beta.response
    local stable_latest = stable_response and stable_response.status == 200
      and about.parse_latest_info(stable_response.body, task.component.asset_pat) or nil
    local beta_latest = beta_response and beta_response.status == 200
      and about.parse_beta_info(beta_response.body) or nil
    local requested = probe.channels[task.component.key]
    local latest = requested == "beta" and beta_latest or stable_latest
    if requested == "beta" and not beta_latest then latest = stable_latest end
    local installed = about.installed_entry(probe.installed, task.component.key)
    if about.compare_state(installed, latest) == "update" then available = true end
  end
  probe.result = { success = true, pending = false, available = available }
  return probe.result
end

-- ── Update All: open the user's terminal running the installer ──────────────

-- Known terminal emulators, in preference order, with how each runs a program:
--   dashe    : <bin> -e bash <script>      (xterm, konsole, x-terminal-emulator)
--   dashdash : <bin> -- bash <script>      (gnome-terminal, ptyxis)
--   x        : <bin> -x bash <script>      (xfce4-terminal: -x = exec the rest)
--   direct   : <bin> bash <script>         (kitty)
about.TERMINALS = {
  { bin = "x-terminal-emulator", mode = "dashe" },
  { bin = "gnome-terminal",      mode = "dashdash" },
  { bin = "ptyxis",              mode = "dashdash" },
  { bin = "konsole",             mode = "dashe" },
  { bin = "xfce4-terminal",      mode = "x" },
  { bin = "kitty",               mode = "direct" },
  { bin = "alacritty",           mode = "dashe" },
  { bin = "xterm",               mode = "dashe" },
}

-- detect_terminal(which) -> { bin=, mode= } or nil. `which(bin)` returns true if
-- the binary is on PATH; injectable so tests don't depend on the host.
function about.detect_terminal(which)
  for _, t in ipairs(about.TERMINALS) do
    if which(t.bin) then return t end
  end
  return nil
end

-- launch_argv(term, script) -> array of argv tokens to run `bash <script>` in
-- the given terminal. Pure; the caller quotes/spawns.
function about.launch_argv(term, script)
  if term.mode == "dashe" then
    return { term.bin, "-e", "bash", script }
  elseif term.mode == "dashdash" then
    return { term.bin, "--", "bash", script }
  elseif term.mode == "x" then
    return { term.bin, "-x", "bash", script }
  else -- direct
    return { term.bin, "bash", script }
  end
end

-- Single-quote a token for safe POSIX-shell interpolation.
local function shq(s)
  return "'" .. tostring(s):gsub("'", "'\\''") .. "'"
end

-- The bash script the terminal runs: the installer one-liner, then a pause so
-- the window stays open for the user to read the result. No user-controlled
-- input is interpolated (the URL is a constant, and `flags` contains only our
-- fixed option strings), so this is injection-safe. Flags are appended after
-- `bash -s --` so an update keeps the selected channels and install mode.
function about.update_script(install_url, flag)
  local run = "curl -fsSL " .. shq(install_url) .. " | bash"
  local flags = flag
  if type(flags) == "string" then flags = flags ~= "" and { flags } or {} end
  if type(flags) == "table" and #flags > 0 then
    run = run .. " -s -- " .. table.concat(flags, " ")
  end
  return table.concat({
    "#!/usr/bin/env bash",
    "set -u",
    'echo "Updating slsteam-moon / Lumen / LuaTools…"',
    "echo",
    run,
    "status=$?",
    "echo",
    'if [ "$status" -eq 0 ]; then',
    '  echo "Done. Restart Steam to apply the updates."',
    "else",
    '  echo "Update exited with status $status."',
    "fi",
    'read -rp "Press Enter to close this window…" _',
    "",
  }, "\n")
end

-- build_command(argv) -> a detached shell command string (setsid+nohup, output
-- discarded, backgrounded) that survives the caller. argv tokens are quoted.
function about.build_command(argv)
  local parts = {}
  for _, tok in ipairs(argv) do parts[#parts + 1] = shq(tok) end
  return "setsid nohup " .. table.concat(parts, " ") .. " >/dev/null 2>&1 &"
end

-- update_all(opts) -> table {success[, error]}. opts (injectable for tests):
--   which      : PATH probe (defaults to `command -v`)
--   write_file : write the temp script (defaults to io)
--   spawn      : run the detached command (defaults to os.execute)
--   tmp_path   : override the temp script path
--   flag       : extra installer flag to forward (e.g. "--noplugin")
function about.update_all(opts)
  opts = opts or {}
  local which = opts.which or function(bin)
    local f = io.popen("command -v " .. shq(bin) .. " 2>/dev/null", "r")
    if not f then return false end
    local out = f:read("*a") or ""
    f:close()
    return out:gsub("%s+", "") ~= ""
  end
  local write_file = opts.write_file or function(p, text)
    local f = io.open(p, "wb"); if not f then return false end
    f:write(text); f:close(); return true
  end
  local spawn = opts.spawn or function(cmd) return os.execute(cmd) end

  local term = about.detect_terminal(which)
  if not term then
    return {
      success = false,
      error = "No terminal emulator found. Run the installer manually: "
        .. "curl -fsSL " .. about.INSTALL_URL .. " | bash",
    }
  end

  local script = opts.tmp_path or ("/tmp/lumen-update-" .. tostring(os.time()) .. ".sh")
  if not write_file(script, about.update_script(about.INSTALL_URL,
      opts.flags or opts.flag)) then
    return { success = false, error = "Could not write the update script." }
  end

  local argv = about.launch_argv(term, script)
  spawn(about.build_command(argv))
  return { success = true, terminal = term.bin }
end

-- Deterministic installer argv for the unified channel. The installer still
-- receives one flag per component for compatibility and independently falls
-- back to Stable when a component has no Beta artifact. --noplugin removes the
-- absent plugin's flag.
function about.channel_flags(channels, no_plugin)
  channels = about.normalize_channels(channels)
  local flags = {
    "--slsteam-channel", channels.slsteam_moon,
  }
  if not no_plugin then
    flags[#flags + 1] = "--plugin-channel"
    flags[#flags + 1] = channels.plugin
  end
  flags[#flags + 1] = "--lumen-channel"
  flags[#flags + 1] = channels.lumen
  if no_plugin then flags[#flags + 1] = "--noplugin" end
  return flags
end

-- register(registry[, opts]): install GetAboutVersions / UpdateAll, wrapping the
-- table-returning core in JSON encoding (the dispatch contract). opts.no_plugin
-- (a --noplugin install) drops the LuaTools plugin from the version list and
-- forwards --noplugin to the Update All installer run.
function about.register(registry, opts)
  opts = opts or {}
  local no_plugin = opts.no_plugin and true or false
  local channel_path = opts.channels_path or about.channels_path()
  local update_probe, update_result, update_checked_at
  registry.GetAboutVersions = function()
    return json.encode(about.get_versions({
      include_plugin = not no_plugin,
      versions_path = opts.versions_path,
      channels_path = channel_path,
      read_file = opts.read_file,
      http = opts.http,
    }))
  end
  registry.GetAboutUpdateStatus = function()
    local now = os.time()
    if update_result and update_checked_at and now - update_checked_at < 300 then
      return json.encode(update_result)
    end
    if not update_probe then
      update_probe = about.new_update_probe({
        include_plugin = not no_plugin,
        versions_path = opts.versions_path,
        channels_path = channel_path,
        read_file = opts.read_file,
        http = opts.http,
      })
      if not update_probe then
        return json.encode({ success = false, pending = false, available = false })
      end
    end
    local status = about.poll_update_probe(update_probe)
    if status.pending ~= true then
      update_result, update_checked_at, update_probe = status, now, nil
    end
    return json.encode(status)
  end
  registry.SetAboutChannel = function(raw)
    local ok_decode, req = pcall(json.decode, raw or "")
    if not ok_decode or type(req) ~= "table" then
      return json.encode({ success = false, error = "invalid request" })
    end
    local deps = opts.channel_deps or {}
    if opts.read_file and deps.read_file == nil then
      deps.read_file = opts.read_file
    end
    local ok, err = about.set_channel(channel_path, req.channel, deps)
    return json.encode({ success = ok and true or false, error = err })
  end
  registry.UpdateAll = function()
    local channels = about.read_channels(channel_path, opts.read_file)
    return json.encode(about.update_all({
      flags = about.channel_flags(channels, no_plugin),
    }))
  end
  return registry
end

return about
